# rcps-pytorch
Reverse-complement parameter sharing (RCPS) layers for machine learning on DNA sequences in PyTorch
